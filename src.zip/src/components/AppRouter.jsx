import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

import PublicApp from '@/components/public/PublicApp.jsx';
import ClientApp from '@/components/client/ClientApp';
import AdminApp from '@/components/admin/AdminApp';

import AboutUsPage from '@/components/public/pages/AboutUsPage';
import ContactPage from '@/components/public/pages/ContactPage';
import ShippingPage from '@/components/public/pages/ShippingPage';
import ReturnsPage from '@/components/public/pages/ReturnsPage';
import FAQPage from '@/components/public/pages/FAQPage';
import WarrantyPage from '@/components/public/pages/WarrantyPage';

export const AppRouter = () => {
  const { user, profile, loading } = useAuth();

  // Pantalla de carga global
  if (loading || (user && profile === undefined)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-gray-600">Cargando...</p>
      </div>
    );
  }

  // Si no hay usuario → Public app
  if (!user) {
    return (
      <Routes>
        <Route path="/sobre-nosotros" element={<AboutUsPage />} />
        <Route path="/contacto" element={<ContactPage />} />
        <Route path="/envios" element={<ShippingPage />} />
        <Route path="/devoluciones" element={<ReturnsPage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/garantia" element={<WarrantyPage />} />

        <Route path="/*" element={<PublicApp />} />
      </Routes>
    );
  }

  // Usuario autenticado pero sin perfil cargado (ya manejado con undefined)
  if (profile === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-lg text-red-600">
          No se pudo cargar tu perfil. Por favor, vuelve a iniciar sesión.
        </p>
      </div>
    );
  }

  // Rutas del Admin
  if (profile?.role === "admin") {
    return (
      <Routes>
        <Route path="/admin/*" element={<AdminApp />} />
        <Route path="/*" element={<Navigate to="/admin/dashboard" replace />} />
      </Routes>
    );
  }

  // Rutas del Cliente
  if (profile?.role === "client") {
    return (
      <Routes>
        <Route path="/cliente/*" element={<ClientApp />} />
        <Route path="/*" element={<Navigate to="/cliente/productos" replace />} />
      </Routes>
    );
  }

  // fallback general
  return <Navigate to="/" replace />;
};