import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(undefined);
  const [loading, setLoading] = useState(true);

  // 🚀 NUEVO: Cargar cached user + profile instantáneo
  useEffect(() => {
    const cachedUser = localStorage.getItem("auth_user");
    const cachedProfile = localStorage.getItem("auth_profile");

    if (cachedUser) {
      setUser(JSON.parse(cachedUser));
    }
    if (cachedProfile) {
      setProfile(JSON.parse(cachedProfile));
    }
  }, []);

  // 🚀 Cargar sesión real Supabase
  useEffect(() => {
    const initialize = async () => {
      const { data: { session } } = await supabase.auth.getSession();

      if (session?.user) {
        setUser(session.user);
        localStorage.setItem("auth_user", JSON.stringify(session.user));

        await loadUserProfile(session.user.id);
      } else {
        setUser(null);
        setProfile(null);
        localStorage.removeItem("auth_user");
        localStorage.removeItem("auth_profile");
      }

      setLoading(false);
    };

    initialize();

    const { data: listener } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (session?.user) {
          setUser(session.user);
          localStorage.setItem("auth_user", JSON.stringify(session.user));
          await loadUserProfile(session.user.id);
        } else {
          setUser(null);
          setProfile(null);
          localStorage.removeItem("auth_user");
          localStorage.removeItem("auth_profile");
        }
      }
    );

    return () => listener.subscription.unsubscribe();
  }, []);

  // 🚀 Carga de perfil + persistencia completa
  const loadUserProfile = async (userId) => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    if (error) {
      console.error("Error loading profile:", error);
      setProfile(null);
      localStorage.removeItem("auth_profile");
      return;
    }

    setProfile(data);
    localStorage.setItem("auth_profile", JSON.stringify(data));
  };

  const login = async (email, password) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      toast({
        title: "Error al iniciar sesión",
        description: error.message,
        variant: "destructive",
      });
      setLoading(false);
      return false;
    }

    return true;
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: window.location.origin },
      });

      if (error) {
        toast({
          title: "Error con Google",
          description: error.message,
          variant: "destructive",
        });
        setLoading(false);
        return false;
      }
      
      return true;
    } catch {
      toast({
        title: "Error inesperado",
        description: "No se pudo iniciar con Google",
        variant: "destructive",
      });
      setLoading(false);
      return false;
    }
  };

  const register = async (dataUser) => {
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: dataUser.email,
      password: dataUser.password,
      options: { data: { full_name: dataUser.name } },
    });

    if (error) {
      toast({
        title: "Error en registro",
        description: error.message,
        variant: "destructive",
      });
      setLoading(false);
      return false;
    }

    toast({
      title: "Registrado con éxito",
      description: "Revisa tu correo para confirmar tu cuenta.",
    });

    return true;
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    localStorage.removeItem("auth_user");
    localStorage.removeItem("auth_profile");
  };

  const value = {
    user,
    profile,
    loading,
    isAuthenticated: !!user,
    isAdmin: profile?.role === "admin",
    isClient: profile?.role === "client",
    login,
    loginWithGoogle,
    register,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};