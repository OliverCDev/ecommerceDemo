import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';

const DataContext = createContext();
export const useData = () => useContext(DataContext);

// -----------------------------
// 🔵 Helpers de persistencia
// -----------------------------
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
const load = (key, fallback) => {
  const v = localStorage.getItem(key);
  return v ? JSON.parse(v) : fallback;
};

export const DataProvider = ({ children }) => {
  const { user, profile } = useAuth();

  // -----------------------------
  // 🔵 Estado persistente
  // -----------------------------
  const [products, setProducts] = useState(() => load("products_cache", []));
  const [categories, setCategories] = useState(() => load("categories_cache", []));
  const [orders, setOrders] = useState(() => load("orders_cache", []));
  const [customers, setCustomers] = useState(() => load("customers_cache", []));
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);


  // ------------------------------------------
  // 🔵 FETCH general — SOLO SE EJECUTA UNA VEZ
  // ------------------------------------------
  const fetchCategories = useCallback(async () => {
    const { data, error } = await supabase
      .from("categories")
      .select("*")
      .order("name");

    if (!error && data) {
      setCategories(data);
      save("categories_cache", data);
    }

    return data || [];
  }, []);

  const fetchProducts = useCallback(async () => {
    const { data, error } = await supabase
      .from("products")
      .select(`*, categories(id, name)`)
      .order("name");

    if (!error && data) {
      const formatted = data.map((p) => ({
        ...p,
        category: p.categories?.name,
        categoryId: p.category_id,
      }));
      setProducts(formatted);
      save("products_cache", formatted);
    }

    return data || [];
  }, []);

  const fetchOrders = useCallback(async () => {
    if (!profile) return [];

    let query = supabase.from("orders").select(`
      *,
      profiles(id, full_name, email),
      order_items(*, products(id, name, image_url))
    `);

    if (profile.role === "client") {
      query = query.eq("customer_id", profile.id);
    }

    const { data, error } = await query.order("created_at", { ascending: false });

    if (!error && data) {
      const formatted = data.map((o) => ({
        id: o.id,
        customerId: o.customer_id,
        customerName: o.profiles?.full_name,
        customerEmail: o.profiles?.email,
        items: o.order_items.map((it) => ({
          id: it.product_id,
          name: it.products?.name,
          quantity: it.quantity,
          price: it.price_at_purchase,
          imageUrl: it.products?.image_url,
        })),
        total: parseFloat(o.total_amount),
        status: o.status,
        createdAt: o.created_at,
      }));

      setOrders(formatted);
      save("orders_cache", formatted);
      return formatted;
    }

    return [];
  }, [profile]);

  const fetchCustomers = useCallback(async () => {
    if (profile?.role !== "admin") return [];

    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("role", "client")
      .order("full_name");

    if (!error && data) {
      const formatted = data.map((c) => ({
        id: c.id,
        name: c.full_name,
        email: c.email,
        createdAt: c.created_at
      }));

      setCustomers(formatted);
      save("customers_cache", formatted);
      return formatted;
    }

    return [];
  }, [profile]);

  // ------------------------------------------
  // 🟣 Carga inicial — SOLO UNA VEZ POR SESIÓN
  // ------------------------------------------
  useEffect(() => {
    if (!user || !profile) {
      setLoading(false);
      return;
    }

    const loadAll = async () => {
      if (initialized) return;
      setInitialized(true);

      setLoading(true);
      await fetchCategories();
      await fetchProducts();

      await fetchOrders();     // si es cliente -> solo su orden
      await fetchCustomers();  // si es admin -> clientes

      setLoading(false);
    };

    loadAll();
  }, [user, profile]);


  // ------------------------------------------
  // ❌ ELIMINADO: el otro useEffect que recargaba TODO
  // porque causaba loaders infinitos
  // ------------------------------------------


  // ----------------------------
  // 🔵 CRUD (se mantiene igual)
  // pero después de cada uno se actualiza localStorage
  // ----------------------------

  const addProduct = async (p) => {
    const res = await supabase.from("products").insert({
      name: p.name,
      description: p.description,
      price: p.price,
      category_id: p.categoryId,
      stock: p.stock,
      image_url: p.imageUrl,
      featured: p.featured,
      rating: p.rating
    }).select().single();

    await fetchProducts();
    return res.data;
  };

  // (tu código sigue igual aquí, sin cambios necesarios)

  const value = {
    products,
    categories,
    orders,
    customers,
    loading,

    fetchProducts,
    fetchCategories,
    fetchOrders,
    fetchCustomers,

    addProduct,
    updateProduct,
    deleteProduct,

    addCategory,
    updateCategory,
    deleteCategory,

    createOrder,
    updateOrderStatus,
    getOrdersByCustomer,

    getStats: () => ({
      totalRevenue: orders.reduce((t, o) => t + o.total, 0),
      totalOrders: orders.length,
      totalCustomers: customers.length,
      totalProducts: products.length,
    })
  };

  return (
    <DataContext.Provider value={value}>{children}</DataContext.Provider>
  );
};
